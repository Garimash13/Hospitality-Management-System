package module4;

import java.util.HashSet;

public class question3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashSet<String> fruits = new HashSet<String>();
		fruits.add("apple");
		fruits.add("banana");
		fruits.add("cherry");
		fruits.add("date");
		fruits.add("fig");
		System.out.println("HashSet of fruits is:");
		for(String i: fruits) {
			System.out.print(i + "  ");
		}
		fruits.add("banana");
		int count = 0;
		for(String i: fruits) {
			count ++;
		}
		System.out.println("\nTotal number of fruits in the HashSet is: " + count);

	}

}
