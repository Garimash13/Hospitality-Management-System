package module4;

public class MyCalculator {

public static void power(int n,int p) {
	long result = 1;
    for(int i=0; i<p; i++) {
        result *= n;
    }
   System.out.println("result is :" + result);
}
public static void main(String[] args) {
	try {
		int n = 5;
		int p = 2;
		validateNumber(n,p);
		power(n,p);
	}
	catch(IllegalArgumentException e) {
        System.out.println("IllegalArgumentException caught : " + e.getMessage());
    }
}
public static void validateNumber(int n,int p) {
	if(n < 0 || p <0) {
		throw new IllegalArgumentException("n or p should not be negative");
	}
	if(n == 0 && p == 0) {
		throw new IllegalArgumentException("n and p should not be zero");
	}
}
}

