package module4;
import java.util.ArrayList;

public class question2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Integer> numbers = new ArrayList<>();
		numbers.add(1);
		numbers.add(2);
		numbers.add(3);
		numbers.add(4);
		numbers.add(5);
		System.out.println("ArrayList: " + numbers);
		numbers.add(5, 6);
		System.out.println("ArrayList after adding 6 at the end:");
		for(Integer i: numbers) {
			System.out.print(i + " ");
		}
		System.out.println();
		numbers.add(2, 10);
		System.out.println("ArrayList after adding 10 at index 2:");
		for(Integer i: numbers) {
			System.out.print(i + " ");
		}
		numbers.remove(3);
		System.out.println();
		System.out.println("ArrayList after removing element at index 3");
		for(Integer i : numbers) {
			System.out.print(i + " ");
		}

	}

}
