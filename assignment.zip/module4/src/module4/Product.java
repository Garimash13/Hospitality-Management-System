package module4;

public class Product {
	private String product;
	private double price;
	public Product(String product, double price) {
		this.product = product;
        this.price = price;;
	}
	public String getProduct() {
        return product;
    }
	public double getPrice() {
		return price;
	}
	@Override
	public String toString() {
		return "Product [name = " + product +" Price = " + price +"]";
	}
}
