package module4;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class question4 {

    public static void main(String[] args) {
        // Sample list of products
        List<Product> products = List.of(
            new Product("Laptop", 1500),
            new Product("Smartphone", 800),
            new Product("Tablet", 500),
            new Product("Desk", 1200),
            new Product("Chair", 150)
        );

        // Task 1: Find all products that have a price greater than 1000
        List<Product> expensiveProducts = products.stream()
            .filter(product -> product.getPrice() > 1000)
            .collect(Collectors.toList());

        System.out.println("Products with price greater than 1000: " + expensiveProducts);

        // Task 2: Calculate the total price of all products
        double totalPrice = products.stream()
            .mapToDouble(Product::getPrice)
            .sum();

        System.out.println("Total price of all products: " + totalPrice);

        // Task 3: Find the product with the highest price
        Optional<Product> mostExpensiveProduct = products.stream()
            .max((p1, p2) -> Double.compare(p1.getPrice(), p2.getPrice()));

        mostExpensiveProduct.ifPresent(product ->
            System.out.println("Product with highest price: " + product)
        );

        // Task 4: Create a list of product names sorted alphabetically
        List<String> sortedProductNames = products.stream()
            .map(Product::getProduct)
            .sorted()
            .collect(Collectors.toList());

        System.out.println("Product names sorted alphabetically: " + sortedProductNames);

        // Task 5: Count the number of products in each category (Note: This task is skipped because the Product class does not have a category field)
    }
}

